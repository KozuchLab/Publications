#!/bin/bash
#SBATCH -p gpu,hns
#SBATCH -c 1
#SBATCH --gres gpu:1
#SBATCH --mail-type=ALL
#SBATCH --time=48:00:00
#SBATCH --job-name=PYP_M100K_F96oCNF

ml reset
ml load chemistry gromacs

srun gmx_gpu grompp -f md100.mdp -c npt2.gro -t npt2.cpt -p topol.top -o PYP_md.tpr
srun gmx_gpu mdrun -v -deffnm PYP_md